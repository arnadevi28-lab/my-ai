# My AI — Flutter offline chatbot

This is a starter Flutter app named **My AI**. It runs without an internet connection and uses simple built-in keyword replies. It is not a generative AI model and does not have ChatGPT's knowledge.

## Build an Android APK from an Android phone

This project includes a GitHub Actions workflow so you can build the APK in the cloud without installing Flutter on your phone.

1. Extract `my_ai_flutter.zip` on your phone.
2. Sign in to GitHub and create a new **public** or **private** repository named `my-ai`.
3. Upload the project files and folders from this ZIP to the repository. Make sure `lib/main.dart`, `pubspec.yaml`, and `.github/workflows/build-apk.yml` are at the repository root.
4. Open the repository's **Actions** tab. If GitHub asks, enable Actions.
5. Open **Build My AI APK** and tap **Run workflow**.
6. When the run finishes successfully, open it and scroll to **Artifacts**. Download `my-ai-debug-apk`.
7. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install it. Android may ask you to allow installs from your browser or file manager; only allow this for the APK you built from your own repository.

## Important
- This starter app needs no API key and sends no messages to a server.
- Replies are limited because the chatbot is rule-based, not a full language model.
- The workflow builds a debug APK for testing. A Play Store release needs a separately configured signing key.
